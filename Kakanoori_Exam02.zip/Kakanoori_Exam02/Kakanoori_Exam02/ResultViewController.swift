//
//  ResultViewController.swift
//  Kakanoori_Exam02
//
//  Created by Pravallika Reddy Kakanoori on 11/04/23.
//

import UIKit

class ResultViewController: UIViewController {
    
    @IBOutlet weak var SIDLabel: UILabel!
    
    @IBOutlet weak var ConfirmLabel: UILabel!
    
    @IBOutlet weak var resultImage: UIImageView!
    
    var SID = ""
    var CourseId = ""
    var CourseName = ""
    var ImageName=""
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        resultImage.image=UIImage(named: ImageName)
        SIDLabel.text = "Your Student ID is : \(SID)"
        ConfirmLabel.text = "You have successfully enrolled in: \(CourseId), \(CourseName)"

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
