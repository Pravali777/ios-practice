//
//  ViewController.swift
//  Kakanoori_Exam02
//
//  Created by Pravallika Reddy Kakanoori on 11/04/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var CourseIDOutlet: UITextField!
    
    @IBOutlet weak var StudentIDOutlet: UITextField!
    
    @IBOutlet weak var CourseCheckBtn: UIButton!
    
    @IBOutlet weak var statusLabel: UILabel!
    
    @IBOutlet weak var dispplayImageOutlet: UIImageView!
    
    
    @IBOutlet weak var EnrollBtnOutlet: UIButton!
    var CourseID = ""
    var CourseName = ""
    var imageName = ""
    var courseFound = false
    var Courses = CoursesArray
    override func viewDidLoad() {
        super.viewDidLoad()
        CourseCheckBtn.isEnabled = false
        dispplayImageOutlet.isHidden = true
        EnrollBtnOutlet.isHidden = true
        statusLabel.isHidden = true
        // Do any additional setup after loading the view.
    }
    
    @IBAction func CourseEntered(_ sender: Any) {
        if(CourseIDOutlet.text!.isEmpty) {
            CourseCheckBtn.isEnabled = false
        }
        else {
            CourseCheckBtn.isEnabled=true
        }
    }
    @IBAction func CheckCourseClick(_ sender: Any) {
        var courseID = CourseIDOutlet.text!
        for course in CoursesArray {
            if (courseID == course.courseID) {
                courseFound = true
                
                CourseID=course.courseID
                CourseName=course.courseName
                imageName = course.courseImage
                statusLabel.text = "\(CourseID) is open for registration"
                dispplayImageOutlet.image = UIImage(named: imageName)
                EnrollBtnOutlet.isHidden=false

            }
            else {
                courseFound = false
                EnrollBtnOutlet.isHidden=true
            }
        }        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transistion = segue.identifier
        if(transistion=="resultSegue") {
            var destination = segue.destination as! ResultViewController
            destination.SID = StudentIDOutlet.text!
            destination.CourseId = CourseID
            destination.CourseName = CourseName
            destination.ImageName = imageName
            
        }
    }
    
    
    


}

